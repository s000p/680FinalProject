import SwiftUI

struct CoffeeLogView: View {
    @Environment(\.managedObjectContext) var moc
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath: \Coffee.name, ascending: true)]) var coffees: FetchedResults<Coffee>
    
    var body: some View {
        VStack {
            if coffees.isEmpty {
                Text("No Coffees Recorded")
                    .foregroundColor(.gray)
            } else {
                List {
                    ForEach(coffees, id: \.id) { coffee in
                        HStack {
                            Text(coffee.name ?? "Unnamed")
                                .font(.headline)
                            Text("(\(coffee.type ?? "other"))")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                            Spacer()
                            Text("\(coffee.caffeineContent) mg")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                          
                        }
                    }
                    .onDelete(perform: deleteCoffee)
                }
                .listStyle(PlainListStyle())
            }
        }
        .navigationTitle("Caffeine Log")
    }
    
//delete entry
private func deleteCoffee(at offsets: IndexSet) {
        for index in offsets {
            let coffee = coffees[index]
            moc.delete(coffee)
        }
        
    
        do {
            try moc.save()
        } catch {
            print("Error saving after deletion: \(error.localizedDescription)")
        }
    }
}

#Preview {
    CoffeeLogView()
}
