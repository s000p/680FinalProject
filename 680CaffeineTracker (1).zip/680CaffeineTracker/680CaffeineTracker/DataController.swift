//
//  DataController.swift
//  680CaffeineTracker
//
//  Created by Xcode on 12/5/24.
//
import CoreData
import SwiftUI

class DataController: ObservableObject{
    let container = NSPersistentContainer(name: "CaffeineTracker")
    
    init(){
        container.loadPersistentStores{ description, error in
            if let error = error{
                print("Core Data failed to load: \(error.localizedDescription)")
            }
        }
    }
}
