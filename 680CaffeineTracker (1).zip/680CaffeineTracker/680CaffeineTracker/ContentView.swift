import SwiftUI

struct ContentView: View {
    @Environment(\.managedObjectContext) var moc
    @FetchRequest(sortDescriptors: []) var coffees: FetchedResults<Coffee>
    
    @State private var selectedTab = 0 // Default Home tab
    @State private var showingAddScreen = false
    
    @State private var value = 0.0
    @State private var showValue = false
    
    @State private var caffeineGoal: Double = UserDefaults.standard.double(forKey: "caffeineGoal") == 0 ? 400 : UserDefaults.standard.double(forKey: "caffeineGoal")  // Default to 400mg
    
    // calculating total caffeine
    private var totalCaffeine: Double {
        coffees.isEmpty ? 0 : Double(coffees.map { $0.caffeineContent }.reduce(0, +))
    }
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // Home Tab
            NavigationView {
                VStack {
                    ZStack {
                        Circle()
                            .stroke(lineWidth: 24)
                            .frame(width: 280, height: 280)
                            .foregroundColor(.white)
                            .shadow(color: .black.opacity(0.1), radius: 10, x: 10, y: 10)
                        
                        Circle()
                            .stroke(lineWidth: 0.34)
                            .frame(width: 260, height: 260)
                            .foregroundStyle(LinearGradient(gradient: Gradient(colors: [.black.opacity(0.3), .clear]), startPoint: .bottomTrailing, endPoint: .topLeading))
                            .overlay {
                                Circle()
                                    .stroke(.black.opacity(0.1), lineWidth: 2)
                                    .blur(radius: 5)
                                    .mask {
                                        Circle()
                                            .foregroundStyle(LinearGradient(gradient: Gradient(colors: [.black, .clear]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    }
                            }

                        Circle()
                            .trim(from: 0, to: showValue ? value : 0)
                            .stroke(style: StrokeStyle(lineWidth: 24, lineCap: .round))
                            .frame(width: 280, height: 280)
                            .rotationEffect(.degrees(-90))
                            .foregroundStyle(LinearGradient(gradient: Gradient(colors: [.brown]), startPoint: .bottomTrailing, endPoint: .topLeading))
                        
                        Image("mascot")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 200)
                    }
                    
                    if totalCaffeine != 0 {
                        Text("\(Int(totalCaffeine))mg/\(Int(caffeineGoal))mg consumed")
                            .font(.headline)
                            .padding()
                    } else {
                        Text("No caffeine consumed today!")
                            .font(.headline)
                            .padding()
                    }
                    
                    if totalCaffeine < caffeineGoal {
                        Text("Great job on limiting your caffeine intake")
                            .font(.callout)
                            .padding()
                    } else if totalCaffeine > caffeineGoal {
                        Text("Let's try one less coffee tomorrow...")
                            .font(.callout)
                            .padding()
                    }
                }
                .onAppear {
                    // Update progress circle when caffeine goal or total caffeine changes
                    withAnimation {
                        value = totalCaffeine / caffeineGoal
                        showValue = true
                    }
                }
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button {
                            showingAddScreen.toggle()
                        } label: {
                            Label("Add Coffee", systemImage: "plus")
                        }
                    }
                }
                .sheet(isPresented: $showingAddScreen) {
                    AddView()
                }
            }
            .tabItem {
                Image(systemName: "house")
                Text("Home")
            }
            .tag(0)
            
            // log Tab
            NavigationView {
                CoffeeLogView()
                    .navigationTitle("Log")
            }
            .tabItem {
                Image(systemName: "chart.bar")
                Text("Stats")
            }
            .tag(1)
            
            // Profile Tab
            NavigationView {
                ProfileView(caffeineGoal: $caffeineGoal)
            }
            .tabItem {
                Image(systemName: "person.crop.circle")
                Text("Profile")
            }
            .tag(2)
        }
        .accentColor(.brown)
    }
}

#Preview {
    ContentView()
}
