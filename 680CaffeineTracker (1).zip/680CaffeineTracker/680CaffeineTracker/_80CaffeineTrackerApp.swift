//
//  _80CaffeineTrackerApp.swift
//  680CaffeineTracker
//
//  Created by Xcode on 12/5/24.
//

import SwiftUI

@main
struct _80CaffeineTrackerApp: App {
    @StateObject private var dataController = DataController()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, dataController.container.viewContext)
        }
    }
}
