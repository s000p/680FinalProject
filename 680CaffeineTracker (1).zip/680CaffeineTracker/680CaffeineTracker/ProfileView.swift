import SwiftUI

struct ProfileView: View {
    @Binding var caffeineGoal: Double
    
    @State var username: String = "@catfeine"
    @State private var path = [Int]()
    
    var body: some View {
        NavigationStack(path: $path) {
            VStack {
                // Profile Image
                Image("mascot")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)
                
                // Username Text
                Text(username)
                    .font(.title)
                    .foregroundColor(.brown)
                    .padding(.top, 10)
                
                Button(action: {
                    path.append(1)
                }) {
                    Text("Change Username")
                        .font(.headline)
                        .foregroundColor(.brown)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                }

                Button(action: {
                    path.append(2)
                }) {
                    Text("Change Caffeine Goal")
                        .font(.headline)
                        .foregroundColor(.brown)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                }

            }
            .navigationDestination(for: Int.self) { catNumber in
                if catNumber == 1 {
                    Setting1(username: $username)
                } else if catNumber == 2 {
                    Setting2(caffeineGoal: $caffeineGoal)
                }
            }
        }
    }
}

struct Setting2: View {
    @Binding var caffeineGoal: Double
    
    var body: some View {
        VStack {
            Text("Enter your new caffeine goal")
                .foregroundColor(.brown)
                .padding()
            
            TextField("Enter new caffeine goal", value: $caffeineGoal, format: .number)
                .keyboardType(.numberPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button("Save Caffeine Goal") {
                UserDefaults.standard.set(caffeineGoal, forKey: "caffeineGoal")
                print("New caffeine goal: \(caffeineGoal) mg")
            }
            .padding()
            .foregroundColor(.brown)
        }
        .navigationTitle("Change Daily Caffeine Goal")
    }
}


struct Setting1: View {
    @Binding var username: String

    var body: some View {
        VStack {
            Text("Enter your new username")
                .foregroundColor(.brown)
                        
            TextField("Enter new username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button("Submit") {
                print("Username changed to: \(username)")
            }
            .padding()
        }
        .navigationTitle("Change Username")
    }
}
