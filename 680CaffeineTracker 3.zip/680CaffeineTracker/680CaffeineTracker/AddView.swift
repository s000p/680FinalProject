//
//view for logging a caffeine intake

import SwiftUI

struct AddView: View {
    @Environment(\.managedObjectContext) var moc
    @Environment(\.dismiss) var dismiss
    
    @State private var name = ""
    @State private var caffeineContent: String = ""
    @State private var progressValue: Double = 0.0  // progress bar value
    @State private var caffeineTotal: Int = 0  // total caffeine
    
    // Coffee types for picker
    let types = ["coffee", "energy drink", "tea", "food item", "other"]
    @State private var selectedType = "coffee"  // Default selected type
    
    let maxCaffeine: Double = 400.0
    
    var body: some View {
        NavigationView {
            Form {
                Section {
                    Image("mascotshock")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    
                    //User enters name
                    TextField("Coffee Name", text: $name)
                    
                    //user enters caffeine content in mg
                    TextField("Enter caffeine content in mg", text: $caffeineContent)
                        .keyboardType(.numberPad)
                    
                    Picker("Type", selection: $selectedType) {
                        ForEach(types, id: \.self) { type in
                            Text(type)
                        }
                    }
                
                }
                
                Section {
                    Button("Save") {
                        if let caffeine = Int(caffeineContent), caffeine > 0 {
                            let newCoffee = Coffee(context: moc)
                            newCoffee.id = UUID()
                            newCoffee.name = name
                            newCoffee.caffeineContent = Int16(caffeine)
                            newCoffee.type = selectedType

                            withAnimation(.easeInOut(duration: 0.5)) {
                                do {
                                    try moc.save()
                                } catch {
                                    print("Error saving coffee: \(error.localizedDescription)")
                                }
                            }
                            
                            caffeineTotal += caffeine
                            
                            dismiss()
                        }
                    }
                    .disabled(name.isEmpty || caffeineContent.isEmpty)  // Disable the button if fields are empty
                }
            }
            .navigationTitle("Add Coffee")
        }
    }
}

#Preview {
    AddView()
}
